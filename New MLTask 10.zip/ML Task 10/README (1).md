# Phishing URL Detection

## 📌 Project Overview

This project uses **Machine Learning** to classify records from a phishing URL dataset as **Legitimate** or **Phishing** using a **Decision Tree Classifier**. The dataset is prepared by handling missing and infinite values, and the model is trained and evaluated using a train-test split.

## 🛠️ Technologies Used

- Python
- Pandas
- NumPy
- Matplotlib
- Scikit-learn
- Jupyter Notebook / Google Colab

## 📂 Dataset

The project uses the **PhiUSIIL Phishing URL Dataset**, loaded from:

`PhiUSIIL_Phishing_URL_Dataset (1).csv`

The dataset contains a `label` column used to create the target classes. In this notebook, `label == 0` is mapped to **Phishing**, and other non-missing label values are mapped to **Legitimate**.

## 🧹 Data Preprocessing

The following steps are performed:

- Removed rows with missing target labels
- Selected numerical columns as model features
- Excluded the original `label` column from the features
- Replaced infinite values with missing values
- Filled missing feature values using each column's median

## 🤖 Model Training

A **Decision Tree Classifier** is trained with the following settings:

- `max_depth = 5`
- `class_weight = "balanced"`
- `random_state = 42`

The dataset is split into **80% training data** and **20% testing data**, using stratification to preserve the class distribution.

## 🌳 Decision Tree Visualization

The trained decision tree is plotted to display its decision rules and the features used to make predictions.

## 📊 Model Evaluation

The model is evaluated using:

- **Accuracy** – Overall proportion of correct predictions
- **Precision** – How many predicted phishing cases are actually phishing
- **Recall** – How many actual phishing cases are correctly identified
- **F1-score** – Balance between precision and recall
- **Specificity** – How many legitimate cases are correctly identified
- **Confusion Matrix** – Summary of correct and incorrect predictions for each class

The actual metric values are printed when the notebook is run.

## 📦 Libraries Installation

```bash
pip install pandas numpy matplotlib scikit-learn
```

## ▶️ How to Run

1. Open `Untitled15.ipynb` in Jupyter Notebook or Google Colab.
2. Upload `PhiUSIIL_Phishing_URL_Dataset (1).csv`.
3. Make sure the CSV file path in the notebook matches the uploaded file location.
4. Run all cells from top to bottom.

## 🚀 Conclusion

This project demonstrates how a Decision Tree Classifier can be used to identify phishing-related records from a dataset. The confusion matrix and evaluation metrics help assess the model's classification performance.

**Note:** This is a machine-learning demonstration. Its predictions should not be treated as a guarantee that a URL is safe or malicious.
